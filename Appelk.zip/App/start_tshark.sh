#!/bin/bash
for (( ; ; ))
do
tshark -a duration:120 -i any -t ad -lT fields -E separator=, -E quote=d -e frame.protocols -e frame.time -e frame.len -e eth.src -e eth.src_resolved -e eth.dst -e eth.dst_resolved -e eth.type -e ip.version -e ip.hdr_len -e ip.src -e ip.dst -e ip.len -e ip.ttl -e ip.proto -e ip.geoip.lat -e ip.geoip.lon -e tcp.dstport -e tcp.srcport -e tcp.hdr_len -e tcp.len -e tcp.flags -e tcp.window_size -e udp.dstport -e udp.srcport -e udp.length -e http.request.method -e http.request.uri -e http.user_agent -e http.content_type -e http.connection -e http.request.full_uri -e http.content_length_header -e http.request.version -e http.response.code > "/home/elk/App/tshark_output.csv"
done
