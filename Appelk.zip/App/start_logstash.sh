/usr/share/logstash/bin/logstash -f  /home/elk/APP/tshark_handle.conf --path.settings /etc/logstash

